
Evidence Pack v2.1
Generated at 2026-01-06T13:23:58.348601Z

Key fixes:
 - refined_label sourced from topic_label_map_vpd_refined.csv (unique labels per topic)
 - macro_name only in macro_name column
 - All fig_inputs validated non-empty

Filtered docs: 30561
Unique refined_labels: 157
